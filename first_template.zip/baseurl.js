function apiUrl(){
    return "http://localhost:3003/";
}



export  {apiUrl};

// export {apiUrl,imgurl};